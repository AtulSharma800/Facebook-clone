<?php
  session_start();
    // include 'navbar.php';
  unset($_SESSION['email']);
  session_destroy();

  header('location:login.php');
?>