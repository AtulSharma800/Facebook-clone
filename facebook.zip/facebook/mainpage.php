<?php
session_start();

include 'connect.php';
$email = $_SESSION['email'];
echo $email;
$query="select * from signup where email='$email'";

$run = mysqli_query($conn,$query);
if (mysqli_num_rows($run) > 0) {
    $row = mysqli_fetch_array($run);
    // print_r($row['firstname']);
    $username=strtoupper($row['firstname']." ".$row['lastname']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
       <style>
           .breadcrumb{
               align-items: center;
               padding-left: 600px;
           }
           #username{
               padding-left: 100px;
           }
       </style>
<body>
    <Center>
        <h1>hello facebook </h1>
        <Center>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="profile.php">profile</a></li>
                    <li class="breadcrumb-item"><a href="logout.php">logout</a></li><span id="username"> 
                   </span><?php echo $username?> </span>

                </ol>

            </nav>
        </Center>
    </Center>
</body>

</html>