<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    


<?php
session_start();
$id=$_SESSION['userid'];


include 'connect.php';
if (isset($_POST['liked'])) {
    $postid = $_POST['postid'];
    $result = mysqli_query($conn, "select * from post where id = $postid");
    $row = mysqli_fetch_array($result);
     $id=$_SESSION['userid'];
    $n = $row['likes'];


    $ress="insert into likes(userid,postid) values($id,$postid)";
    mysqli_query($conn, "update post set likes = $n+1 where id=$postid");
    mysqli_query($conn, "insert into likes(userid,postid) values ($id,$postid)");  
    echo $n+1;
    
   


    // exit();
}

if (isset($_POST['unliked'])) {
    // die('how are you');
    echo "unliked";
    $postid = $_POST['postid'];
    $result = mysqli_query($conn, "select * from post where id= $postid");
    $row = mysqli_fetch_array($result);
    $n = $row['likes'];
    mysqli_query($conn, "delete from likes where postid=$postid AND userid=$id");
    mysqli_query($conn, "update post set likes = $n-1 where id=$postid");
    // exit();
}
?>


</body>
</html>