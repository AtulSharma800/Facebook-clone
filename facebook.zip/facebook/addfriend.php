<?php

include 'connect.php';
//  $query = "select * from signup ";

//  $run = mysqli_query($conn, $query);
//  if (mysqli_num_rows($run) > 0) {
//    $row = mysqli_fetch_array($run);
//    $username = strtoupper($row['firstname'] . " " . $row['lastname']);
//  }

?>
<?php include 'bfnavbar.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<style>
    .profile {
        width: 200px;
        height: 100px;
        margin-top: 30px;
        justify-content: center;
        margin-left: 500px;
    }
</style>

<body>
    <?php
    $selectQuery = " select * from signup ";
    $query = mysqli_query($conn, $selectQuery);
    // $nums=mysqli_num_rows($query); //for no of rows in my database
    while ($res = mysqli_fetch_array($query)) {

    ?>
        <div class="profile">
            <img src="assets/profile.png" width="40px" height="40px" />
            <?php echo $res['firstname'] ?><?php echo $res['lastname'] ?><br>
            <?php echo  $res['id'] ?>
            <button class="btn btn-warning" id="btn1">
                <a href="showfriend.php?id=<?php echo $res['id'] ?>">addfriend</a>
            </button>
            <button class="btn btn-warning" id="btn1">
                <a href="delete.php?id=<?php echo $res['id'] ?>">remove</a>
            </button><br><br>
        </div>
    <?php
    }
    ?>
  
    <script>
        $(document).ready(function() {

            $("#btn1").click(function() {
                $(this).hide();
            });
        })
    </script>
</body>

</html>