<?php

include 'connect.php';
$file_name = "";
if (isset($_FILES['image'])) {

    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $folder = 'upload/' . $file_name;
    move_uploaded_file($file_tmp, $folder);

    $query = "insert into post(image)values('$file_name')";
    if ($run = mysqli_query($conn, $query)) {
    } else {
        echo "fail";
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
    <title>multiple post</title>
    <style>
        .container1 {
            margin-top: 20px;
            width: 400px;
            height: 100px;
            background-color: blue;
            border: orange;
            align-items: center;
            display: flex;
            justify-content: center;
        }
    </style>
</head>

<body>
    <?php include 'bfnavbar.php'; ?>
    <center>
        <div class="container1">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                <!-- <input type="file" name="image" accept="image/*"> -->


                <input type="file" name="image" />
                <!-- <div>
                    <img id="blah" src="#" alt="your image" />
                </div> -->
                <input type="submit" name="submit" value="Post">
                 
            </form>
            <!-- validation -->


            <!-- 
            <script>
                function readURL(input) {
                    if (input.files && input.files[0]) {
                        var reader = new FileReader();

                        reader.onload = function(e) {
                            $('#blah')
                                .attr('src', e.target.result)
                                .width(150)
                                .height(150);
                        };

                        reader.readAsDataURL(input.files[0]);
                    }

                }
            </script> -->
        </div>

        <?php include 'display.php'  ?>

    </center>
</body>

</html>