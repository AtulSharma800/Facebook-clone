<?php
session_start();
include 'connect.php';



$db = mysqli_select_db($conn, 'facebook');


$emailerr = $passerr = $password = "";

if (isset($_POST['submit'])) {

    if (empty($_POST["email"])) {
        $emailerr = "email is mandatory";
    }

    if (empty($_POST["password"])) {
        $passerr = "password is mandatory";
    } else {
        $password = $_POST['password'];
    }


    if (isset($_SESSION['email'])) {
        $_SESSION['email'] = $email;
    }
    $email = $_POST['email'];
    // $password = $_POST['password'];
    


    $sql = "select * from signup where email='$email' and password='$password'";
    if ($query = mysqli_query($conn, $sql)) {
        if (mysqli_num_rows($query) == 1) {
            $_SESSION['email'] = $email;
            $_SESSION['userid']=$id;
            echo 'successfully login';
            header('location:bfnavbar.php');
        }else{
            echo 'wrong email or password';
        }
    } else {
        echo 'query fail';

        // header('location:login2.php');
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">

    <link rel="stylesheet" href="style.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <title>Document</title>
</head>
<style>
    .container {

        box-shadow: 10px 10px 8px 10px #888888;

    }
</style>

<body>

    <center>
        <h1>facebook</h1>
        <div class="container">
            <h3>Log in to Facebook</h3>
            <center>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

                    <input type="email" class="input2" name="email" value="" placeholder="Email" autocomplete="off" id="login" /><br>
                    <span class="errorColor">* <?php echo $emailerr; ?></span>
                    <br><br>

                    <input type="password" class="input2" name="password" value="" placeholder="Password" autocomplete="off" id="login" /><br>
                    <span class="errorColor">* <?php echo $passerr; ?></span>
                    <br><br>


                    <button type="submit" name="submit" class="button">Login</button>
                    <br><a href="forgot.php">Forgotten password?</a>
                    <br><span>Have a account?</span><span> <a href="signup.php">SignUp Here</a></span>

                </form>


            </center>
        </div>

</body>

</html>