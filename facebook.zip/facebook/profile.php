<?php
session_start();
include 'connect.php';
$email = $_SESSION['email'];
$query = "select * from signup where email='$email'";

$run = mysqli_query($conn, $query);
if (mysqli_num_rows($run) > 0) {
  $row = mysqli_fetch_array($run);
  // print_r($row['firstname']);
  $username = strtoupper($row['firstname'] . " " . $row['lastname']);
}
?>
<!-- <?php include 'bfnavbar.php'; ?> -->

<!DOCTYPE html>
<html lang="en">
    
<head>                                                                                
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <title>Document</title>
</head>
              
<body>
  
  <center>
     
  <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
  <form>
      <input type="name" value="<?php echo $row['firstname'] ?>"><br><br>
      <input type="name" value="<?php echo $row['lastname'] ?>"><br><br>
      <input type="email" value="<?php echo $row['email'] ?>"><br><br>
      <input type="name" value="<?php echo $row['date'] ?>"><br><br>
      <input type="name" value="<?php echo $row['gender'] ?>"><br><br>
    </form>
  </div>
</div>
   
  </center>



</body>

</html>