<?php
      include 'connect';

      if(isset($_POST['submit'])){
          
      }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">

    <title>Document</title>
    <style>
        h2{
            padding-top: 50px;
            color: rgb(9, 36, 245);
            margin-bottom: 20px;
        }
        .container{
            padding-top: 20px;
            height: 100px;
            width: 300px;
            background-color: lightblue;
        }
        input{
            width: 200px;
            height: 25px;

        }
        button{height: 30px; width: 100px;color:white;background-color: blue;border: none;}

    </style>
</head>

<body>
    <center>
        <div>
            <h2>Forgotten Password </h2>
            <div class="container">

            <form method="post" action="<?php echo  htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                      <input type="email"  name="email" placeholder="email" ><br><br>
                       <button type="submit" name="submit" >Send Mail</button>
                    </form>
                    <a href="login.php">Already have an account</a>

            </div>
        </div>
    </center>

</body>

</html>