<?php
include 'connect.php';
session_start();
$ids = $_SESSION['userid'];
echo $ids;

$id = $_GET['id'];
echo $id;
$friend_id = $id;
$query = "insert into addfriend (user_id,friend_id) values($ids,$friend_id)";
$run = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $query = "SELECT * FROM addfriend inner join signup on addfriend.user_id='$ids'=signup.id='$id' where addfriend.user_id=6 ";
    $run = mysqli_query($conn, $query);
    while ($res = mysqli_fetch_array($run)) {
            //  print_r($res['email']);
    ?>
        
    <?php
    }
    ?>


  

</body>

</html>