
<?php
   include 'connect.php';
       
   $firsterror=$lasterror=$passerr=$email=$firstname=$lastname=$dateerr=$emailerr='';
     
   if(isset($_POST['submit'])){


    if (empty($_POST["firstname"])) {
        $firsterror = "firstname is mandatory";
    } else {
        $firstname = $_POST["firstname"];
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/", $firstname)) {
            $firsterror = "Only letters allowed";
        }
    }

    if (empty($_POST["lastname"])) {
        $lasterror = "lastname is mandatory";
    } else {
        $lastname = $_POST["lastname"];
        // check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/", $firstname)) {
            $lasterror = "Only letters allowed";
        }
    }

    if (empty($_POST["email"])) {
        $emailerr = "number is mandatory";
    } else {
        $email = $_POST['email'];
    }    
    
    
    if (empty($_POST['password'])) {
        $passerr = 'password must have entered';
    } else {
        $password = $_POST['password'];
        $uppercase = preg_match('@[A-Z]@', $password);
        $lowercase = preg_match('@[a-z]@', $password);
        $number    = preg_match('@[0-9]@', $password);
        $specialChars = preg_match('@[^\w]@', $password);

        if (strlen($password) < 8) {
            $passerr = 'Password should be at least 8 characters ';
        }
        if (!$uppercase) {
            $passerr = 'one uppercase mandatory';
        }
        if (!$lowercase) {
            $passerr = 'one lowercase mandatory';
        }
        if (!$specialChars) {
            $passerr = 'one specialChars mandatory';
        }
        if (!$number) {
            $passerr = 'one number mandatory';
        } else {
            $password = $_POST['password'];
        }
 
        
    }

    if(empty($_POST['date'])){
        $dateerr="date is mandatory";
    }
    else{
        $date=$_POST['date'];

    }
    

    $mobilequery = "select * from signup where email='" . $email . "'";

    if ($result = mysqli_query($conn, $mobilequery)) {

        if ($result->num_rows > 0) {
            // print_r(mysqli_fetch_array($result));

            echo "<br>";
            $emailerr = 'email is already exits';
            $err = 1;
        }
    }



    if(empty($firsterror)&&empty($lasterror)&&empty($emailerr)&&empty($dateerr)&&empty($passerr)){
          
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $gender=$_POST['gender'];
    $date=date("y-m-d",strtotime($_POST['date']));


    $query ="insert into signup(firstname,lastname,email,password,gender,date) values('$firstname','$lastname','$email','$password','$gender','$date')";
     if($run=mysqli_query($conn,$query)){

       echo "<script> alert('data saved successfully');</script>";
     
  }
    }
    else{
        echo 'fail';
    }
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
    <style>
        #input1 {
            margin-left: 10px;
        }
        
.container1{
    width: 400px;
    height: 470px;
    /* background-color: rgb(239, 234, 234); */
    background-color: white;
    border: 1px solid black;
    box-shadow: 10px 10px 8px 10px #888888;

}
    </style>
</head>

<body>
    <center>
        <div class="heading">
            <h1>facebook</h1>
            <div class="container1">

                <h2> Create a new account </h2>
                <h4>it's quick and easy </h4>

                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

                    <input type="text" name="firstname" value="" placeholder="firstname" /><span><input type="text" id="input1" name="lastname" value="" placeholder="Surname" /></span><br>
                    <span class="errorColor">* <?php echo $firsterror; ?></span> <span class="errorColor">* <?php echo $lasterror; ?></span>

                    
                    <input type="email" name="email" id="input2" value="" placeholder="email" /><br>
                    <span class="errorColor">* <?php echo $emailerr; ?><br>
                    <input type="password" name="password" id="input2" value="" placeholder="password" /><br>
                    <span class="errorColor">* <?php echo $passerr; ?><br>
                    <input type="radio" id="gender" name="gender" value="male" checked>Male</input>
                    <input type="radio" id="gender" name="gender" value="female">Female</input>
                    <input type="radio" id="gender" name="gender" value="other">other</input><br><br>

                     <input type="date" name="date"><br>
                     <span class="errorColor">* <?php echo $dateerr; ?>
                    <br><input type="submit" name="submit" value="SignUp" class="submit">
                    <a href="login.php">Already have an account</a>
                </form>


            </div>

        </div>

    </center>


</body>

</html>